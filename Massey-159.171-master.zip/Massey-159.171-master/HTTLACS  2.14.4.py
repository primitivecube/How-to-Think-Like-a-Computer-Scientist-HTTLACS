#Start the Python interpreter and enter bruce + 4 at the prompt. This will give you an
#error:
#nameError: name ’bruce’ is not defined
#Assign a value to bruce so that bruce + 4 evaluates to 10.

