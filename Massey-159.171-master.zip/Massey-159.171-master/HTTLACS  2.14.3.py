#Place a comment before a line of code that previously worked, and record what happens
#hen you rerun the program.

a = 4 + 4
#print(a)
