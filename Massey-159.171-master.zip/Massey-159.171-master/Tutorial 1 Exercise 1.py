a = 20; b = 10; c = 15; d = 5
e = (a + b) * c / d # 90
print("Value is ", e)
e = ((a + b) * c) / d # 90
print("Value is", e)
e = (a + b) * (c / d) # 90
print ("Value is",e)
e = a + (b * c) / d # 50
print ("Value is", e)
e = a + (b * c) % d # 20
print ("Value is", e)
