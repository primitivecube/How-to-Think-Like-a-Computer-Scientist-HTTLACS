list = [12, 10, 32, 3, 66, 17, 42, 99, 20]
for number in list:
    print(number)

for number in list:
    print(number, (number ** 2))
