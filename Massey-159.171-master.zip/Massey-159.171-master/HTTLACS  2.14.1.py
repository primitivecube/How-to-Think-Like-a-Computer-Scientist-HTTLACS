#Take the sentence: All work and no play makes Jack a dull boy. Store each word in a
#separate variable, then print out the sentence on one line using print.

a = "all"
b = "work"
c = "and"
d = "no"
e = "play"
f = "makes"
g = "Jack"
h = "a"
i = "dull"
j = "boy"
print(a,b,c,d,e,f,g,h,i,j)
