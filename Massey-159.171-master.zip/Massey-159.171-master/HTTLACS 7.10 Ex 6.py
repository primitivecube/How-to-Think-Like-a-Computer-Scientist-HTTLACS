import math

def findHypot(a, b):
    # your code here
    # a**2 + b**2 = c**2 # 3**2 + 4**2 = 5**2
    # c**2 = a**2 + b**2
    # C = math.sqrt(a**2 + b**2)
    return math.sqrt(a**2 + b**2)

print(findHypot(3,4))



