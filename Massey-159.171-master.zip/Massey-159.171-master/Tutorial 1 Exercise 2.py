x = 3
y = x+5 # 8
x = 6
print(x, y) # 6 8

m = 3
n = m # 3
m = m+2 # 5
print(m, n) # 5 3

x = 0.5
y = 10*x # 5
x = x + 0.1 # 0.6
print(x, y) # 0.6 5.0

print(type(x), type(y))
