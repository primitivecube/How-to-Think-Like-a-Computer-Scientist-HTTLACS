# In Robert McCloskey’s book Make Way for Ducklings,
# the names of the ducklings are Jack, Kack, Lack, Mack, Nack, Ouack, Pack, and Quack.
# This loop tries to output these names in order

prefixes = ['J','K','L','M','N','Ou','P','Qu']
suffix = "ack"

for p in prefixes:
    print(p + suffix)

