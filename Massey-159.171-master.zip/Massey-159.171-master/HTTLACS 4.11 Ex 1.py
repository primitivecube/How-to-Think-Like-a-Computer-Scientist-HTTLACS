for i in range (100):
    print("We like Python's turtles!")
